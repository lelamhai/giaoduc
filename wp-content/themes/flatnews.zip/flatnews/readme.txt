v2.7.4.8 - Apr 03, 2017
- Fixed: can not change footer message in customizer
- Fixed: wrong label of footer logo image in customizer

v2.6 - Mar 25, 2017
- New: support select background color for main header row
- Fixed: demo can not be installed in some cases

v2.3 - Feb 22, 2017
- Fixed: Disqus comment counter not work
- Fixed: sticky menu not work properly when sneak scrolling

2.2
- Fixed: columns not responsive
- Fixed: admin bar not display properly



































When release:
- change //	$min = '.min';


Todo:
- Allow showing break news on mobile
- Regard After header sidebar on mobile