<?php
require_once FLATNEWS_THEME_PATH_WIDGETS . 'widgets-lib.php';
require_once FLATNEWS_THEME_PATH_WIDGETS . 'widgets-article-blocks.php';


require_once FLATNEWS_THEME_PATH_WIDGETS . 'widgets-facebook-page.php';
require_once FLATNEWS_THEME_PATH_WIDGETS . 'widgets-social-counter.php';
require_once FLATNEWS_THEME_PATH_WIDGETS . 'widgets-quote.php';
require_once FLATNEWS_THEME_PATH_WIDGETS . 'widgets-social-icons.php';
require_once FLATNEWS_THEME_PATH_WIDGETS . 'widgets-image.php';
require_once FLATNEWS_THEME_PATH_WIDGETS . 'widgets-categories.php';
require_once FLATNEWS_THEME_PATH_WIDGETS . 'widgets-html.php';