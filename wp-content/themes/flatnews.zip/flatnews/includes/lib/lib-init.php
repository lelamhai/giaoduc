<?php

require_once FLATNEWS_THEME_PATH_LIB . 'lib-common.php';
require_once FLATNEWS_THEME_PATH_LIB . 'lib-article.php';
require_once FLATNEWS_THEME_PATH_LIB . 'lib-next-prev.php';