<?php
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-basic.php';
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-required-plugins.php';
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-menus.php';
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-article-blocks.php';
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-widgets.php';
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-customizer.php';
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-post-meta-box.php';
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-user-meta-box.php';
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-shortcodes.php';
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-page-builder.php';
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-dashboard.php';
require_once FLATNEWS_THEME_PATH_SETUP . 'setup-woocommerce.php';
