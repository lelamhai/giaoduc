<?php

require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-lib.php';

// for article / layout boxes
require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-sidebar.php';
require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-column.php';
require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-article-blocks.php';

// for content
require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-lock.php';
require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-contact.php';
require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-dropcap.php';
require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-button.php';
require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-message.php';
require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-tabs.php';
require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-accordion.php';
require_once FLATNEWS_THEME_PATH_SHORTCODES . 'shortcodes-text.php';
// fixing for code box