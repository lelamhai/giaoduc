<?php
require_once FLATNEWS_THEME_PATH_AJAX . 'ajax-social-counter.php';
require_once FLATNEWS_THEME_PATH_AJAX . 'ajax-save-comment-count.php';
require_once FLATNEWS_THEME_PATH_AJAX . 'ajax-block-pagination.php';
require_once FLATNEWS_THEME_PATH_AJAX . 'ajax-woocommerce.php';
