<?php
function fn_block_pagination($args) {	
	echo fn_block($args['type'], $args, '0');
	die();
}
