<?php 
fn_display_sidebar('fn-main-sidebar');