<?php

global $Sneeit_Articles_Loaded_Posts;
$Sneeit_Articles_Loaded_Posts = array();

include_once 'articles-lib.php';
include_once 'articles-pagination.php';
include_once 'articles-fields.php';
include_once 'articles-query-item.php';
include_once 'articles-query.php';
include_once 'articles-singular.php';
